﻿//  Written by Tyler Gerritsen
//  vtgerritsen@gmail.com

//  1.0 2019-08-09  Functional
//  1.1 2019-12-05  Fixed G92 E1 bug
//  1.2 2019-12-05  Enter % increase during runtime
//                  Can process multiple files simultaneously
using System;
using System.IO;
using System.Text;

class GFG
{
    public static void Main(string[] args)
    {
        bool foundPath = false;
        int percentIncrease = 50;
        for (int i = 0; i < args.Length; i++)
        {
            if (("      " + args[i]).Substring(("      " + args[i]).Length - 6).ToLower() == ".gcode")
            {
                foundPath = true;
                Console.WriteLine(args[i]);
            }
        }
        if (!foundPath || args.Length < 1)
        {
            Console.WriteLine("Please include .gcode file");
            Console.WriteLine("For more information, please visit www.td0g.ca");
            Console.WriteLine();
            Console.WriteLine("Press Any Key To Continue...");
            Console.ReadKey();
            Environment.Exit(-1);
        }
        Console.WriteLine("Infill Density Multiplier 1.2 - Works With Cura");
        Console.WriteLine("Please enter % increase to infill extrusion");
        Console.WriteLine("eg. 50% = 1.5x more infill extrusion");
        string infillString = "";
        while (infillString == "")
        {
            try {
                infillString = Console.ReadLine();
                percentIncrease = int.Parse(infillString);
            }
            catch
            {
                infillString = "";
                Console.WriteLine("Please enter integer value");
            }
        }
        Console.WriteLine();
        Console.WriteLine("BEGINNING");

        //########################################################################################
        //                          Begin
        //########################################################################################
        for (int arg = 0; arg < args.Length; arg++)
        {
            if (("      " + args[arg]).Substring(("      " + args[arg]).Length - 6).ToLower() == ".gcode")
            {
                string[] gcode = File.ReadAllLines(args[arg], Encoding.UTF8);
                string oName = args[arg].Replace(".", "_inf.");
                double extrusionOffset = 0;
                double extrusionOffsetTotal = 0;
                int isInfill = 0;
                double lastExtrusionIn = 0;
                double extrusionIn = 0;
                double relExtrusion = 0;
                double increase = percentIncrease;
                increase /= 100;
                Console.WriteLine("Infill Density Increased " + (increase * 100).ToString() + "%");
                oName = oName.Replace(".gcode", ".tmp");

                //########################################################################################
                //                          Parse all Gcode
                //########################################################################################
                string path = oName;
                string gc;
                using (StreamWriter objFile = File.CreateText(path))
                {
                    for (int i = 0; i < gcode.Length; i++)
                    {
                        gc = gcode[i];
                        if (gc.IndexOf(";") > -1)
                        {
                            if (gc.IndexOf("FILL") > -1)
                            {
                                isInfill = 1;
                            }
                            else if (gc.IndexOf("TYPE") > -1)
                            {
                                isInfill = 0;
                            }
                        }
                        if (gc.Substring(0, 3) == "G00" || gc.Substring(0, 3) == "G01" || gc.Substring(0, 3) == "G0 " || gc.Substring(0, 3) == "G1 ")
                        {
                            string[] g = gc.Split(' ');
                            for (int j = 0; j < g.Length; j++)
                            {
                                if (g[j].Length > 0)
                                {
                                    g[j] = g[j].Replace(" ", "");
                                    if (g[j].Substring(0, 1) == "E")
                                    {
                                        extrusionIn = float.Parse(g[j].Replace("E", ""));
                                        relExtrusion = extrusionIn - lastExtrusionIn;
                                        if (isInfill == 1)
                                        {
                                            extrusionOffset += relExtrusion * increase;
                                            extrusionOffsetTotal += relExtrusion * increase;
                                        }
                                        objFile.Write("E" + (Math.Round((extrusionIn + extrusionOffset), 5).ToString()) + " ");
                                        lastExtrusionIn = extrusionIn;
                                    }
                                    else
                                    {
                                        objFile.Write(g[j]);
                                        objFile.Write(" ");
                                    }
                                }
                            }
                            objFile.WriteLine();
                        }
                        else
                        {
                            objFile.WriteLine(gc);
                            if (gc == "G92 E0")
                            {
                                extrusionOffset = 0;
                                lastExtrusionIn = 0;
                            }
                            else if (gc == "G92 E1")
                            {
                                extrusionOffset = 0;
                                lastExtrusionIn = 0;
                            }
                        }
                    }
                }

                //########################################################################################
                //                          Wrap It Up
                //########################################################################################

                //Rename .tmp to .gcode
                if (System.IO.File.Exists(oName.Replace(".tmp", ".gcode"))) System.IO.File.Delete(oName.Replace(".tmp", ".gcode")); //try/catch exception handling needs to be implemented
                System.IO.File.Move(oName, oName.Replace(".tmp", ".gcode"));

                //Notify User
                
                Console.WriteLine("Output to " + oName);
                Console.WriteLine((Math.Round((extrusionOffsetTotal), 2).ToString()) + " mm extrusion added\n");
            }
        }
        Console.WriteLine("DONE\n\nPress Any Key To Continue...");
        Console.ReadKey();
    }
}