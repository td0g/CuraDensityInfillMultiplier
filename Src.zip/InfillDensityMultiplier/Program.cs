﻿//  Written by Tyler Gerritsen
//  vtgerritsen@gmail.com

//  1.0 2019-08-09  Functional
using System;
using System.IO;
using System.Text;

class GFG
{

    public static void Main(string[] args)
    {
        if (args.Length < 1)
        {
            Console.WriteLine("Please include .gcode file");
            Console.WriteLine("For more information, please visit www.td0g.ca");
            Console.WriteLine();
            Console.WriteLine("Press Any Key To Continue...");
            Console.ReadKey();
            Environment.Exit(-1);
        }

        bool foundPath = false;
        int percentIncrease = 50;
        for (int i = 0; i < args.Length; i++)
        {
            Console.WriteLine(args[i]);
            if (args[i].Length > 6)
            {
                if (args[i].Substring(args[i].Length - 6) == ".gcode") foundPath = true;
            }
            if (args[i].Substring(0, 1) == "-")
            {
                percentIncrease = int.Parse(args[i].Substring(1));
            }
        }
        if (!foundPath)
        {
            Console.WriteLine("Please include .gcode file");
            Console.WriteLine("For more information, please visit www.td0g.ca");
            Console.WriteLine();
            Console.WriteLine("Press Any Key To Continue...");
            Console.ReadKey();
            Environment.Exit(-1);
        }
        string oName = args[0].Replace(".", "_inf.");
        string[] gcode = File.ReadAllLines(args[0], Encoding.UTF8);
        Console.WriteLine("Infill Density Multiplier - Works With Cura");
        Console.WriteLine("To adjust density, run with argument -[PERCENT_INCREASE_INTEGER]");
        Console.WriteLine();
        Console.WriteLine("BEGINNING");
        Console.WriteLine();

        //########################################################################################
        //                          Begin
        //########################################################################################

        double extrusionOffset = 0;
        double extrusionOffsetTotal = 0;
        int isInfill = 0;
        double lastExtrusionIn = 0;
        double extrusionIn = 0;
        double relExtrusion = 0;
        double increase = percentIncrease;
        increase /= 100;
        Console.WriteLine("Infill Density Increased " + (increase * 100).ToString() + "%");
        Console.WriteLine();
        oName = oName.Replace(".gcode", ".tmp");

        //########################################################################################
        //                          Parse all Gcode
        //########################################################################################
        string path = oName;
        string gc;
        using (StreamWriter objFile = File.CreateText(path))
        {
            for (int i = 0; i < gcode.Length; i++)
            {
                gc = gcode[i];
                if (gc.IndexOf(";") > -1)
                {
                    if (gc.IndexOf("FILL") > -1)
                    {
                        isInfill = 1;
                    }
                    else if (gc.IndexOf("TYPE") > -1)
                    {
                        isInfill = 0;
                    }
                }
                if (gc.Substring(0, 3) == "G00" || gc.Substring(0, 3) == "G01" || gc.Substring(0, 3) == "G0 " || gc.Substring(0, 3) == "G1 ")
                {
                    string[] g = gc.Split(' ');
                    for (int j = 0; j < g.Length; j++)
                    {
                        if (g[j].Length > 0)
                        {
                            g[j] = g[j].Replace(" ", "");
                            if (g[j].Substring(0, 1) == "E")
                            {
                                extrusionIn = float.Parse(g[j].Replace("E", ""));
                                relExtrusion = extrusionIn - lastExtrusionIn;
                                if (isInfill == 1)
                                {
                                    extrusionOffset += relExtrusion * increase;
                                    extrusionOffsetTotal += relExtrusion * increase;
                                }
                                objFile.Write("E" + (Math.Round((extrusionIn + extrusionOffset),5).ToString()) + " ");
                                lastExtrusionIn = extrusionIn;
                            }
                            else
                            {
                                objFile.Write(g[j]);
                                objFile.Write(" ");
                            }
                        }
                    }
                    objFile.WriteLine();
                }
                else
                {
                    objFile.WriteLine(gc);
                    if (gc == "G92 E0"){
                        extrusionOffset = 0;
                        lastExtrusionIn = 0;
                    }
                }
            }
        }

        //########################################################################################
        //                          Wrap It Up
        //########################################################################################

        //Rename .tmp to .gcode
        if (System.IO.File.Exists(oName.Replace(".tmp", ".gcode"))) System.IO.File.Delete(oName.Replace(".tmp", ".gcode")); //try/catch exception handling needs to be implemented
        System.IO.File.Move(oName, oName.Replace(".tmp", ".gcode"));

        //Notify User
        Console.WriteLine("DONE");
        Console.Write("Output to ");
        Console.WriteLine(oName);
        Console.Write((Math.Round((extrusionOffsetTotal), 2).ToString()) + " ");
        Console.WriteLine("mm extrusion added");
        Console.WriteLine();
        Console.WriteLine("Press Any Key To Continue...");
        Console.ReadKey();
    }
}