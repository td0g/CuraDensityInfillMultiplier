﻿//  Written by Tyler Gerritsen
//  vtgerritsen@gmail.com

//  1.0 2019-08-09  Functional
//  1.1 2019-12-05  Fixed G92 E1 bug
//  1.2 2019-12-05  Enter % increase during runtime
//                  Can process multiple files simultaneously
//  1.3 2019-12-05  New Infill Prime feature

using System;
using System.IO;
using System.Text;

class GFG
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Infill Density Multiplier 1.3 - Works With Cura");

        //Check that we have gcode files
        bool foundPath = false;
        for (int i = 0; i < args.Length; i++)
        {
            if (("      " + args[i]).Substring(("      " + args[i]).Length - 6).ToLower() == ".gcode")
            {
                foundPath = true;
                Console.WriteLine(args[i]);
            }
        }
        if (!foundPath || args.Length < 1)  //NOPE!  Notify user and exit program.
        {
            Console.WriteLine("Please include .gcode file");
            Console.WriteLine("For more information, please visit www.td0g.ca");
            Console.WriteLine();
            Console.WriteLine("Press Any Key To Continue...");
            Console.ReadKey();
            Environment.Exit(-1);
        }

        //Ask for infill multiply amount
        Console.WriteLine("Please enter % increase to infill extrusion");
        Console.WriteLine("eg. 50% = 1.5x more infill extrusion");
        string infillString = "";
        double increase = 0;
        while (infillString == "")
        {
            try {
                infillString = Console.ReadLine();
                increase = (double)int.Parse(infillString.Replace("%","")) / 100;
            }
            catch
            {
                infillString = "";
                Console.WriteLine("Please enter integer value");
            }
        }

        //Ask for infill prime amount
        Console.WriteLine("\nPlease enter extra prime amount for infill");
        Console.WriteLine("0.02 is a good place to start (?)");
        Console.WriteLine("Enter 0 for no extra infill prime");
        string primeString = "";
        double primeDistance = 0;
        while (primeString == "")
        {
            try
            {
                primeString = Console.ReadLine();
                primeDistance = double.Parse(primeString.Replace("m", ""));
                if (primeDistance < 0)
                {
                    primeString = "";
                    Console.WriteLine("Must be postive amount");
                }
            }
            catch
            {
                primeString = "";
                Console.WriteLine("Please enter floating-point value");
            }
        }
        Console.WriteLine();
        Console.WriteLine("BEGINNING");

        //########################################################################################
        //                          Begin
        //########################################################################################
        for (int arg = 0; arg < args.Length; arg++)
        {
            if (("      " + args[arg]).Substring(("      " + args[arg]).Length - 6).ToLower() == ".gcode")
            {
                string[] gcode = File.ReadAllLines(args[arg], Encoding.UTF8);
                string oName = args[arg].Replace(".", "_inf.");
                double extrusionOffset = 0;
                double extrusionOffsetTotal = 0;
                bool isInfill = false;
                double lastExtrusionIn = 0;
                double extrusionIn = 0;
                double relExtrusion = 0;
                bool isPrimed = false;
                Console.WriteLine("Infill Density Increased " + (increase * 100).ToString() + "%");
                Console.WriteLine("Infill Prime Added " + (primeDistance).ToString() + "mm");

                //########################################################################################
                //                          Parse all Gcode
                //########################################################################################
                using (StreamWriter objFile = File.CreateText(oName.Replace(".gcode", ".tmp")))
                {
                    for (int i = 0; i < gcode.Length; i++)
                    {
                        string gc = gcode[i];
                        if (gc.IndexOf(";") > -1)
                        {
                            if (gc.IndexOf("FILL") > -1)
                            {
                                isInfill = true;
                                if (!isPrimed && primeDistance > 0.000001)
                                {
                                    objFile.WriteLine("G01 E" + (Math.Round(primeDistance + lastExtrusionIn,5)).ToString());
                                    extrusionOffset += primeDistance;
                                    isPrimed = true;
                                }
                            }
                            else if (gc.IndexOf("TYPE") > -1)
                            {
                                isInfill = false;
                                if (isPrimed && primeDistance > 0.000001)
                                {
                                    objFile.WriteLine("G01 E" + (Math.Round(lastExtrusionIn - primeDistance, 5)).ToString());
                                    extrusionOffset -= primeDistance;
                                    isPrimed = false;
                                }
                            }
                        }
                        if (gc.Substring(0, 3) == "G00" || gc.Substring(0, 3) == "G01" || gc.Substring(0, 3) == "G0 " || gc.Substring(0, 3) == "G1 ")
                        {
                            string[] g = gc.Split(' ');
                            for (int j = 0; j < g.Length; j++)
                            {
                                if (g[j].Length > 0)
                                {
                                    g[j] = g[j].Replace(" ", "");
                                    if (g[j].Substring(0, 1) == "E")
                                    {
                                        extrusionIn = float.Parse(g[j].Replace("E", ""));
                                        relExtrusion = extrusionIn - lastExtrusionIn;
                                        if (isInfill)
                                        {
                                            extrusionOffset += relExtrusion * increase;
                                            extrusionOffsetTotal += relExtrusion * increase;
                                        }
                                        objFile.Write("E" + (Math.Round((extrusionIn + extrusionOffset), 5).ToString()) + " ");
                                        lastExtrusionIn = extrusionIn;
                                    }
                                    else
                                    {
                                        objFile.Write(g[j]);
                                        objFile.Write(" ");
                                    }
                                }
                            }
                            objFile.WriteLine();
                        }
                        else
                        {
                            objFile.WriteLine(gc);
                            if (gc == "G92 E0")
                            {
                                extrusionOffset = 0;
                                lastExtrusionIn = 0;
                            }
                            else if (gc == "G92 E1")
                            {
                                extrusionOffset = 0;
                                lastExtrusionIn = 0;
                            }
                        }
                    }
                }

                //########################################################################################
                //                          Wrap It Up
                //########################################################################################

                //Rename .tmp to .gcode
                try
                {
                    if (System.IO.File.Exists(oName)) System.IO.File.Delete(oName);
                    System.IO.File.Move(oName.Replace(".gcode", ".tmp"), oName);
                    //Notify User
                    Console.WriteLine("Output to " + oName);
                    Console.WriteLine((Math.Round((extrusionOffsetTotal), 2).ToString()) + " mm extrusion added\n");
                }
                catch
                {
                    if (System.IO.File.Exists(oName.Replace(".gcode", ".tmp"))) System.IO.File.Delete(oName.Replace(".gcode", ".tmp"));
                }
                //Do next file
            }
        }
        Console.WriteLine("DONE\n\nPress Any Key To Continue...");
        Console.ReadKey();
    }
}